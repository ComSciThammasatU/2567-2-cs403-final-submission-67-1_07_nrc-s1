const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql2')
const app = express() 
const port = process.env.PORT || 5002;
const session = require('express-session');


const path = require('path');
app.use(express.static(path.join(__dirname, 'public'))); 
app.set('view engine', 'ejs');


app.use(session({
  secret: '1234567890abcdefghijklmnopqrstuvwxyz', 
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } 
}));




app.use(bodyParser.json()) 
app.use(bodyParser.urlencoded({ extended: false }))
app.set('view engine','ejs')

// MYSQL connect phpMyAdmin
const pool = mysql.createPool({
    connectionLimit : 10,
    connectTimeout : 20,
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'pharmacy_db2'
})

var obj = {}

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
  });

  
  
///project01 
app.get('/showitem', (req, res) => {

    pool.getConnection((err, connection) => {
        if(err) throw err
        console.log("connect id : ", connection.threadId) 

        connection.query('SELECT * FROM products', (err, rows) => { 
            connection.release();
            if (!err) {

                obj = { products: rows, Error: err }
            

                res.render('showitem', obj)
            
            
            } else {
                console.log(err)
            }

        })
    })
})

app.get('/additem', (req,res) => {
    res.render('additem')
})
///project02
app.post('/additem', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // ถ้าไม่มี id ซ้ำ, ทำการเพิ่มข้อมูลใหม่
        connection2.query('INSERT INTO products SET ?', params, (err, rows) => {
            connection2.release(); // ปล่อยการเชื่อมต่อ
            if (err) {
                console.log(err);
                res.status(500).send('การเพิ่มข้อมูลล้มเหลว');
            } else {
                const obj = { Error: err, mesg: `เพิ่มข้อมูล ${params.product_name} สำเร็จ` };
                res.render('additem', obj);
            }
        });
    });
});

app.get('/addcustomers', (req,res) => {
    res.render('addcustomers')
})
///project03
app.post('/addcustomers', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // Query เพื่อเพิ่มข้อมูลเข้าไปในตาราง customers
        connection2.query('INSERT INTO customers SET ?', params, (err, result) => {
            connection2.release(); // ปล่อยการเชื่อมต่อ

            if (err) {
                console.log(err);
                res.status(500).send('การเพิ่มข้อมูลล้มเหลว: ' + err.message);
                return;
            }

            // หากเพิ่มข้อมูลสำเร็จ ส่งผลลัพธ์กลับไป
            res.redirect('/index');

            
        });
    });
    
});
///project04
app.get('/showpersonal', (req, res) => {

    pool.getConnection((err, connection) => {
        if(err) throw err
        console.log("connect id : ", connection.threadId) 

        connection.query('SELECT * FROM customers', (err, rows) => { 
            connection.release();
            if (!err) {

                obj = { customers: rows, Error: err }
            

                res.render('showpersonal', obj)
            
            
            } else {
                console.log(err)
            }

        })
    })
})

app.get('/addmembership', (req,res) => {
    res.render('addmembership')
})


app.get('/', (req, res) => {
    res.render('index', { results: [] });
  });
  ///project5
app.post('/search', (req, res) => {
    const keyword = req.body.keyword;
    const query = `SELECT * FROM products WHERE product_name LIKE ?`;

    pool.query(query, [`%${keyword}%`], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            return res.status(500).send('Error executing query: ' + err.message);
        }

        if (results.length === 0) {
            return res.render('index', { results: [], relatedDrugs: [] });
        }

        // ดึง ingredients ทั้งหมดจากยาที่ค้นหา (เอาเฉพาะค่าที่ไม่เป็น null)
        const ingredients = results.map(r => r.ingredients).filter(i => i);

        if (ingredients.length === 0) {
            return res.render('index', { results, relatedDrugs: [] });
        }

        // ค้นหายาที่มี ingredients เดียวกัน (แต่ไม่รวมตัวเอง)
        const relatedQuery = `
            SELECT DISTINCT * FROM products 
            WHERE FIND_IN_SET(ingredients, ?) > 0 
            AND product_name NOT LIKE ?;
        `;

        pool.query(relatedQuery, [ingredients.join(','), `%${keyword}%`], (err, relatedDrugs) => {
            if (err) {
                console.error('Error executing related query:', err);
                return res.status(500).send('Error executing related query: ' + err.message);
            }

            res.render('index', { results, relatedDrugs: relatedDrugs || [] });
        });
    });
});

///project06
app.post('/search_member', (req, res) => {
    const keyword = req.body.keyword;
  
    // ตรวจสอบการป้อนข้อมูลเพื่อป้องกันการค้นหาที่ไม่มีค่า
    if (!keyword || keyword.trim() === '') {
      return res.status(400).send('กรุณาใส่คำค้นหา');
    }
  
    const query = `SELECT * FROM customers WHERE first_name LIKE ?`;
  
    // ใช้ pool ในการ query พร้อม parameter อย่างถูกต้อง
    pool.query(query, [`%${keyword}%`], (err, results) => {
      if (err) {
        console.error('เกิดข้อผิดพลาดในการ query:', err);
        return res.status(500).send('เกิดข้อผิดพลาดในการ query: ' + err.message);
      }
  

      res.render('checkout', { results });
    });
  });
 ///project07
app.post('/add-to-cart', (req, res) => {
    const productId = req.body.productId;
    const quantity = req.body.quantity;
  
    // ตรวจสอบจำนวนสินค้าในสต็อกจากตาราง products
    const getStockQuery = `SELECT stock_quantity, price, product_name FROM products WHERE product_id = ?`;
    pool.query(getStockQuery, [productId], (err, productResult) => {
      if (err) {
        console.error('Error fetching product:', err);
        return res.status(500).send('Error fetching product: ' + err.message);
      }
  
      if (productResult.length === 0) {
        return res.status(404).send('Product not found');
      }
  
      const stockQuantity = productResult[0].stock_quantity;
      const unitPrice = productResult[0].price;
      const productName = productResult[0].product_name;
  
      if (quantity > stockQuantity) {
        return res.status(400).send('Error: Quantity exceeds stock available.');
      }
  
      const customerId = req.body.customerId;
      const getOrderQuery = `SELECT order_id FROM orders WHERE customer_id = ? AND total_amount IS NULL`;
      pool.query(getOrderQuery, [customerId], (err, orderResult) => {
        if (err) {
          console.error('Error checking orders:', err);
          return res.status(500).send('Error checking orders: ' + err.message);
        }
  
        let orderId;
        if (orderResult.length === 0) {
          const createOrderQuery = `INSERT INTO orders (customer_id, order_date) VALUES (?, NOW())`;
          pool.query(createOrderQuery, [customerId], (err, orderInsertResult) => {
            if (err) {
              console.error('Error creating new order:', err);
              return res.status(500).send('Error creating new order: ' + err.message);
            }
            orderId = orderInsertResult.insertId;
            addProductToOrder(orderId, productId, quantity, unitPrice, productName);
          });
        } else {
          orderId = orderResult[0].order_id;
          addProductToOrder(orderId, productId, quantity, unitPrice, productName);
        }
      });
    });
  
    function addProductToOrder(orderId, productId, quantity, unitPrice, productName) {
      const totalPrice = unitPrice * quantity;
  
      const addToCartQuery = `INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)`;
      pool.query(addToCartQuery, [orderId, productId, quantity, unitPrice, totalPrice], (err) => {
        if (err) {
          console.error('Error adding product to cart:', err);
          return res.status(500).send('Error adding product to cart: ' + err.message);
        }
  
        const updateStockQuery = `UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?`;
        pool.query(updateStockQuery, [quantity, productId], (err) => {
          if (err) {
            console.error('Error updating stock:', err);
            return res.status(500).send('Error updating stock: ' + err.message);
          }
  
          // บันทึกข้อมูลสินค้าใน session ตะกร้าสินค้า
          if (!req.session.cart) {
            req.session.cart = [];
          }
          req.session.cart.push({
            productId,
            productName,
            quantity,
            unitPrice,
            totalPrice
          });

          res.redirect('/cart');
        });
      });
    }
  });
///project08
  app.get('/cart', (req, res) => {
    if (!req.session.cart || req.session.cart.length === 0) {
      return res.send('ตะกร้าสินค้าว่าง');
    }
  
    let cartItems = req.session.cart;

    res.render('cart', { cartItems });
  });
///project09
  app.get('/checkout', (req, res) => {
    // ตรวจสอบว่ามีข้อมูลตะกร้าสินค้าใน session หรือไม่
    if (!req.session.cart || req.session.cart.length === 0) {
      return res.send('ไม่มีสินค้าที่จะชำระเงิน');
    }
  
    // ดึงข้อมูลตะกร้าสินค้าจาก session
    const cartItems = req.session.cart;
    console.log(req.session.cart);
    // ส่งข้อมูลไปยังหน้า checkout.ejs
    res.render('checkout', { cartItems });
  });
///project10
app.post('/checkout', (req, res) => {
    const customerId = req.body.customerId;

    const getOrderQuery = `SELECT order_id FROM orders WHERE customer_id = ? AND total_amount IS NULL`;
    pool.query(getOrderQuery, [customerId], (err, orderResult) => {
        if (err) {
            console.error('Error checking orders:', err);
            return res.status(500).send('Error checking orders: ' + err.message);
        }

        let orderId;
        if (orderResult.length === 0) {
            return res.status(400).send('ไม่พบคำสั่งซื้อ');
        } else {
            orderId = orderResult[0].order_id;

            // ✅ แก้ตรงนี้: ใช้ unitPrice แทน product_price
            let totalAmount = req.session.cart.reduce((total, item) => {
                return total + (item.unitPrice * item.quantity);
            }, 0);

            const updateOrderQuery = `UPDATE orders SET total_amount = ?, payment_method = ? WHERE order_id = ?`;
            pool.query(updateOrderQuery, [totalAmount, req.body.paymentMethod, orderId], (err) => {
                if (err) {
                    console.error('Error updating order:', err);
                    return res.status(500).send('Error updating order: ' + err.message);
                }

                // ✅ ล้างตะกร้าหลังสั่งซื้อเสร็จ
                req.session.cart = [];

                res.send('ยืนยันการสั่งซื้อสำเร็จ');
            });
        }
    });
});

///project11
app.get('/get-discount', async (req, res) => {
    const first_name = req.query.customer_name;
    console.log("Received customer_name:", first_name);

    try {
        const [rows] = await pool.promise().query(
            'SELECT membership_id FROM customers WHERE first_name LIKE ?',
            [`%${first_name}%`]
        );

        console.log("Query rows:", rows);

        const customer = rows.length > 0 ? rows[0] : null;

        if (!customer) {
            console.log("No customer found with the given name.");
            return res.status(404).json({ message: "Customer not found" });
        }

        let discount = 0;
        if (customer.membership_id === 1) discount = 0.05;
        else if (customer.membership_id === 2) discount = 0.10;
        else if (customer.membership_id === 3) discount = 0.15;

        res.json({ discount });
    } catch (error) {
        console.error("Error in /get-discount route:", error);
        res.status(500).json({ error: "Failed to fetch discount" });
    }
});

///project12
app.get('/', (req, res) => {
    pool.getConnection((err, connection) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error connecting to the database');
        }
        console.log("Connected with ID:", connection.threadId);

        connection.query('SELECT * FROM products', (err, rows) => { 
            connection.release();
            if (!err) {
                const obj = { products: rows };
                res.render('index', obj);
            } else {
                console.error(err);
                return res.status(500).send('Error querying the database');
            }
        });
    });
});

///project13
app.post('/ ', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // ตรวจสอบว่ามี membership_id ในตาราง memberships หรือไม่
        connection2.query('SELECT * FROM memberships WHERE membership_id = ?', [params.membership_id], (err, results) => {
            if (err) {
                connection2.release();
                console.log(err);
                res.status(500).send('การค้นหาข้อมูลสมาชิกล้มเหลว');
                return;
            }

            if (results.length === 0) {
                // หากไม่มี membership_id นี้ในตาราง memberships ให้เพิ่มเข้าไปก่อน
                connection2.query('INSERT INTO memberships (membership_id) VALUES (?)', [params.membership_id], (err) => {
                    if (err) {
                        connection2.release();
                        console.log(err);
                        res.status(500).send('การเพิ่มข้อมูลสมาชิกใหม่ล้มเหลว');
                        return;
                    }

                    // หลังจากเพิ่มข้อมูลสมาชิกแล้ว ให้เพิ่มข้อมูลลูกค้า
                    addCustomer(connection2, params, res);
                });
            } else {
                // ถ้ามี membership_id แล้ว ให้เพิ่มข้อมูลลูกค้าได้เลย
                addCustomer(connection2, params, res);
            }
        });
    });
});
///project14
app.post('/place-order', (req, res) => {
    // รับ customer_id จาก session แทนค่าคงที่ (ควรมีระบบล็อกอิน)
    const customerId = req.session.customer_id || 1; // ใช้ค่าจริงจาก session ถ้ามี
    const { total_amount, discounted_total, payment_method } = req.body;

    // ตรวจสอบว่ามีข้อมูลที่จำเป็นครบถ้วน
    if (!total_amount || !discounted_total || !payment_method) {
        return res.status(400).send("Missing required fields");
    }

    // ตรวจสอบว่าค่าเป็นตัวเลข
    if (isNaN(discounted_total) || isNaN(total_amount)) {
        return res.status(400).send("Invalid amount value");
    }

    console.log('Request Body:', req.body); // Log เพื่อตรวจสอบข้อมูลที่รับมา

    const sql = `
        INSERT INTO orders (customer_id, total_amount, payment_method)
        VALUES (?, ?, ?)
    `;

    // บันทึกคำสั่งลงฐานข้อมูล
    pool.query(sql, [customerId, discounted_total, payment_method], (err, result) => {
        if (err) {
            console.error('Error in placing the order:', err);
            return res.status(500).send(`Error in placing the order: ${err.message}`);
        }

        console.log('Insert Result:', result); // ตรวจสอบผลลัพธ์จาก MySQL
        req.session.cart = [];
        // Redirect ไปยังหน้าสำเร็จหลังจากสั่งซื้อเสร็จ
        res.redirect('/thankyou');

    });
});
app.get('/thankyou', (req, res) => {
    res.render('thankyou');
});

app.get('/index', (req, res) => {
    res.redirect('/');
});

///project15
app.get('/showalerts', async (req, res) => {
    await checkAndCreateAlerts(req, res);
});
// ฟังก์ชันตรวจสอบสินค้าใกล้หมดและสินค้าใกล้หมดอายุ
async function checkAndCreateAlerts(req, res) {
    const lowStockThreshold = 100; /// ปรับค่าตามความเหมาะสมของสต็อกต่ำสุด
    const expirationThreshold = 90;/// ปรับค่าตามจำนวนวันก่อนหมดอายุที่ต้องการแจ้งเตือน
    let alertData = [];

    try {
        // ตรวจสอบสินค้าใกล้หมด
        const [lowStockResults] = await pool.promise().query(
            `SELECT product_id, stock_quantity FROM products WHERE stock_quantity < ?`,
            [lowStockThreshold]
        );

        const lowStockPromises = lowStockResults.map(async (product) => {
            // ตรวจสอบการแจ้งเตือนสินค้ารายการนี้อยู่แล้วหรือไม่
            const [existingAlert] = await pool.promise().query(
                `SELECT * FROM alerts WHERE product_id = ? AND alert_type = 'สินค้าใกล้หมด'`,
                [product.product_id]
            );

            if (existingAlert.length === 0) {
                // ถ้ายังไม่มีการแจ้งเตือน ให้เพิ่มการแจ้งเตือนใหม่
                const [result] = await pool.promise().query(
                    `INSERT INTO alerts (product_id, alert_type, alert_date) VALUES (?, 'สินค้าใกล้หมด', NOW())`,
                    [product.product_id]
                );
                
                alertData.push({
                    alert_id: result.insertId,
                    product_id: product.product_id,
                    alert_type: 'สินค้าใกล้หมด',
                    alert_date: new Date().toISOString()
                });
            }
        });

        // ตรวจสอบสินค้าใกล้หมดอายุ
        const [expirationResults] = await pool.promise().query(
            `SELECT product_id, expiry_date FROM products WHERE expiry_date <= NOW() + INTERVAL ? DAY`,
            [expirationThreshold]
        );

        const expirationPromises = expirationResults.map(async (product) => {
            // ตรวจสอบการแจ้งเตือนสินค้ารายการนี้อยู่แล้วหรือไม่
            const [existingAlert] = await pool.promise().query(
                `SELECT * FROM alerts WHERE product_id = ? AND alert_type = 'สินค้าใกล้หมดอายุ'`,
                [product.product_id]
            );

            if (existingAlert.length === 0) {
                // ถ้ายังไม่มีการแจ้งเตือน ให้เพิ่มการแจ้งเตือนใหม่
                const [result] = await pool.promise().query(
                    `INSERT INTO alerts (product_id, alert_type, alert_date) VALUES (?, 'สินค้าใกล้หมดอายุ', NOW())`,
                    [product.product_id]
                );

                alertData.push({
                    alert_id: result.insertId,
                    product_id: product.product_id,
                    alert_type: 'สินค้าใกล้หมดอายุ',
                    alert_date: new Date().toISOString()
                });
            }
        });

        // รอให้ทุก query ทำงานเสร็จ
        await Promise.all([...lowStockPromises, ...expirationPromises]);

        // หลังจากสร้างแจ้งเตือนครบแล้ว ค่อย render
        res.render('showalert', { alerts: alertData });
    } catch (err) {
        console.error('Error:', err);
        res.status(500).send('เกิดข้อผิดพลาด');
    }
}
///project16
app.post("/check-warnings", (req, res) => {
    const { customer_name, product_ids } = req.body;
  
    console.log(" เข้าสู่ /check-warnings");
    console.log(" customer_name:", customer_name);
    console.log(" product_ids:", product_ids);
  
    // 🔎 ดึง chronic_diseases ของลูกค้า
    pool.query(
      "SELECT chronic_diseases FROM customers WHERE first_name = ?",
      [customer_name],
      (err, customerRows) => {
        if (err) {
          console.error(" เกิดข้อผิดพลาดในการดึงข้อมูลลูกค้า:", err);
          return res.status(500).json({ error: "เกิดข้อผิดพลาดในการตรวจสอบ" });
        }
  
        console.log(" customerRows:", customerRows);
  
        if (!customerRows || customerRows.length === 0) {
          console.warn(` ไม่พบชื่อลูกค้า: ${customer_name}`);
          return res.json({ warnings: [`ไม่พบชื่อลูกค้า "${customer_name}"`] });
        }
  
        const chronic = customerRows[0].chronic_diseases || "";
        console.log(" chronic_diseases (raw string):", chronic);
  
        const customerConditions = chronic
          .split(",")
          .map((c) => c.trim())
          .filter((c) => c);
  
        console.log(" customerConditions (array):", customerConditions);
  
        //  ดึงข้อมูลยา
        pool.query(
          "SELECT product_id, product_name, warning_conditions FROM products WHERE product_id IN (?)",
          [product_ids],
          (err, productRows) => {
            if (err) {
              console.error(" เกิดข้อผิดพลาดในการดึงข้อมูลยา:", err);
              return res.status(500).json({ error: "เกิดข้อผิดพลาดในการตรวจสอบยา" });
            }
  
            console.log(" productRows:", productRows);
  
            const warnings = [];
  
            for (const product of productRows) {
              const warningConditions = product.warning_conditions
                ? product.warning_conditions.split(",").map((w) => w.trim())
                : [];
  
              console.log(` ตรวจสอบยา: "${product.product_name}"`);
              console.log("    warning_conditions:", warningConditions);
  
              const matched = customerConditions.filter((condition) =>
                warningConditions.includes(condition)
              );
  
              console.log("    matched warnings:", matched);
  
              if (matched.length > 0) {
                warnings.push(`"${product.product_name}" ห้ามใช้กับ: ${matched.join(", ")}`);
              }
            }
  
            console.log(" คำเตือนทั้งหมด:", warnings);
  
            res.json({ warnings });
          }
        );
      }
    );
  });
  
  ///project17
  app.get('/get-customer-weight', (req, res) => {
    const customerName = req.query.customer_name;
    console.log("Received customer_name:", customerName);

    pool.query('SELECT weight FROM customers WHERE first_name LIKE ?', [`%${customerName}%`], (err, rows) => {
        if (err) {
            console.error('Error fetching weight:', err);
            return res.status(500).json({ error: "ไม่สามารถดึงข้อมูลน้ำหนักได้" });
        }

        if (rows.length === 0) {
            return res.status(404).json({ message: "ไม่พบลูกค้าตามชื่อที่กรอก" });
        }

        res.json({ weight: rows[0].weight });
    });
});
///project18
app.get('/get-recommended-dosage', (req, res) => {
    const customerWeight = parseFloat(req.query.weight);
    
    pool.query('SELECT * FROM dosage_guidelines WHERE weight_min <= ? AND weight_max >= ?', [customerWeight, customerWeight], (err, rows) => {
        if (err) {
            console.error('Error fetching dosage guidelines:', err);
            return res.status(500).json({ error: "ไม่สามารถดึงข้อมูลโดสยาได้" });
        }

        if (rows.length === 0) {
            return res.status(404).json({ message: "ไม่พบคำแนะนำโดสยาตามน้ำหนักนี้" });
        }

        res.json({ recommended_dosage: rows[0].dosage });
    });
});

  
  
  