const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql2')
const app = express() 
const port = process.env.PORT || 5001;
const session = require('express-session');

app.use(session({
  secret: '1234567890abcdefghijklmnopqrstuvwxyz', 
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } 
}));


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'pharmacy_db' 
}).promise();

db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database.');
});

app.use(bodyParser.json()) 
app.use(bodyParser.urlencoded({ extended: false }))
app.set('view engine','ejs')

// MYSQL connect phpMyAdmin
const pool = mysql.createPool({
    connectionLimit : 10,
    connectTimeout : 20,
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'pharmacy_db'
})

var obj = {}


app.get('/showitem', (req, res) => {

    pool.getConnection((err, connection) => {
        if(err) throw err
        console.log("connect id : ", connection.threadId) 

        connection.query('SELECT * FROM products', (err, rows) => { 
            connection.release();
            if (!err) {

                obj = { products: rows, Error: err }
            

                res.render('showitem', obj)
            
            
            } else {
                console.log(err)
            }

        })
    })
})

app.get('/additem', (req,res) => {
    res.render('additem')
})

app.post('/additem', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // ถ้าไม่มี id ซ้ำ, ทำการเพิ่มข้อมูลใหม่
        connection2.query('INSERT INTO products SET ?', params, (err, rows) => {
            connection2.release(); // ปล่อยการเชื่อมต่อ
            if (err) {
                console.log(err);
                res.status(500).send('การเพิ่มข้อมูลล้มเหลว');
            } else {
                const obj = { Error: err, mesg: `เพิ่มข้อมูล ${params.product_name} สำเร็จ` };
                res.render('additem', obj);
            }
        });
    });
});

app.get('/addcustomers', (req,res) => {
    res.render('addcustomers')
})

app.post('/addcustomers', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // Query เพื่อเพิ่มข้อมูลเข้าไปในตาราง customers
        connection2.query('INSERT INTO customers SET ?', params, (err, result) => {
            connection2.release(); // ปล่อยการเชื่อมต่อ

            if (err) {
                console.log(err);
                res.status(500).send('การเพิ่มข้อมูลล้มเหลว: ' + err.message);
                return;
            }

            // หากเพิ่มข้อมูลสำเร็จ ส่งผลลัพธ์กลับไป
            res.status(200).send({ message: 'เพิ่มข้อมูลเรียบร้อย', id: result.insertId });
        });
    });
    
});

app.get('/showpersonal', (req, res) => {

    pool.getConnection((err, connection) => {
        if(err) throw err
        console.log("connect id : ", connection.threadId) 

        connection.query('SELECT * FROM customers', (err, rows) => { 
            connection.release();
            if (!err) {

                obj = { customers: rows, Error: err }
            

                res.render('showpersonal', obj)
            
            
            } else {
                console.log(err)
            }

        })
    })
})

app.get('/addmembership', (req,res) => {
    res.render('addmembership')
})

app.post('/ ', (req, res) => {
    const params = req.body;

    // ตรวจสอบการเชื่อมต่อกับฐานข้อมูล
    pool.getConnection((err, connection2) => {
        if (err) {
            console.log(err);
            res.status(500).send('การเชื่อมต่อฐานข้อมูลล้มเหลว');
            return;
        }

        // ตรวจสอบว่ามี membership_id ในตาราง memberships หรือไม่
        connection2.query('SELECT * FROM memberships WHERE membership_id = ?', [params.membership_id], (err, results) => {
            if (err) {
                connection2.release();
                console.log(err);
                res.status(500).send('การค้นหาข้อมูลสมาชิกล้มเหลว');
                return;
            }

            if (results.length === 0) {
                // หากไม่มี membership_id นี้ในตาราง memberships ให้เพิ่มเข้าไปก่อน
                connection2.query('INSERT INTO memberships (membership_id) VALUES (?)', [params.membership_id], (err) => {
                    if (err) {
                        connection2.release();
                        console.log(err);
                        res.status(500).send('การเพิ่มข้อมูลสมาชิกใหม่ล้มเหลว');
                        return;
                    }

                    // หลังจากเพิ่มข้อมูลสมาชิกแล้ว ให้เพิ่มข้อมูลลูกค้า
                    addCustomer(connection2, params, res);
                });
            } else {
                // ถ้ามี membership_id แล้ว ให้เพิ่มข้อมูลลูกค้าได้เลย
                addCustomer(connection2, params, res);
            }
        });
    });
});

app.get('/', (req, res) => {
    res.render('index', { results: [] });
  });
  
app.post('/search', (req, res) => {
    const keyword = req.body.keyword;
    const query = `SELECT * FROM products WHERE product_name LIKE ?`;
  
    // ใช้ pool ในการ query
    pool.query(query, [`%${keyword}%`], (err, results) => {
      if (err) {
        console.error('Error executing query:', err);
        return res.status(500).send('Error executing query: ' + err.message);
      }
      res.render('index', { results });
    });
  });

app.post('/search_member', (req, res) => {
    const keyword = req.body.keyword;
  
    // ตรวจสอบการป้อนข้อมูลเพื่อป้องกันการค้นหาที่ไม่มีค่า
    if (!keyword || keyword.trim() === '') {
      return res.status(400).send('กรุณาใส่คำค้นหา');
    }
  
    const query = `SELECT * FROM customers WHERE first_name LIKE ?`;
  
    // ใช้ pool ในการ query พร้อม parameter อย่างถูกต้อง
    pool.query(query, [`%${keyword}%`], (err, results) => {
      if (err) {
        console.error('เกิดข้อผิดพลาดในการ query:', err);
        return res.status(500).send('เกิดข้อผิดพลาดในการ query: ' + err.message);
      }
  

      res.render('checkout', { results });
    });
  });
 
app.post('/add-to-cart', (req, res) => {
    const productId = req.body.productId;
    const quantity = req.body.quantity;
  
    // ตรวจสอบจำนวนสินค้าในสต็อกจากตาราง products
    const getStockQuery = `SELECT stock_quantity, price, product_name FROM products WHERE product_id = ?`;
    pool.query(getStockQuery, [productId], (err, productResult) => {
      if (err) {
        console.error('Error fetching product:', err);
        return res.status(500).send('Error fetching product: ' + err.message);
      }
  
      if (productResult.length === 0) {
        return res.status(404).send('Product not found');
      }
  
      const stockQuantity = productResult[0].stock_quantity;
      const unitPrice = productResult[0].price;
      const productName = productResult[0].product_name;
  
      if (quantity > stockQuantity) {
        return res.status(400).send('Error: Quantity exceeds stock available.');
      }
  
      const customerId = req.body.customerId;
      const getOrderQuery = `SELECT order_id FROM orders WHERE customer_id = ? AND total_amount IS NULL`;
      pool.query(getOrderQuery, [customerId], (err, orderResult) => {
        if (err) {
          console.error('Error checking orders:', err);
          return res.status(500).send('Error checking orders: ' + err.message);
        }
  
        let orderId;
        if (orderResult.length === 0) {
          const createOrderQuery = `INSERT INTO orders (customer_id, order_date) VALUES (?, NOW())`;
          pool.query(createOrderQuery, [customerId], (err, orderInsertResult) => {
            if (err) {
              console.error('Error creating new order:', err);
              return res.status(500).send('Error creating new order: ' + err.message);
            }
            orderId = orderInsertResult.insertId;
            addProductToOrder(orderId, productId, quantity, unitPrice, productName);
          });
        } else {
          orderId = orderResult[0].order_id;
          addProductToOrder(orderId, productId, quantity, unitPrice, productName);
        }
      });
    });
  
    function addProductToOrder(orderId, productId, quantity, unitPrice, productName) {
      const totalPrice = unitPrice * quantity;
  
      const addToCartQuery = `INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)`;
      pool.query(addToCartQuery, [orderId, productId, quantity, unitPrice, totalPrice], (err) => {
        if (err) {
          console.error('Error adding product to cart:', err);
          return res.status(500).send('Error adding product to cart: ' + err.message);
        }
  
        const updateStockQuery = `UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?`;
        pool.query(updateStockQuery, [quantity, productId], (err) => {
          if (err) {
            console.error('Error updating stock:', err);
            return res.status(500).send('Error updating stock: ' + err.message);
          }
  
          // บันทึกข้อมูลสินค้าใน session ตะกร้าสินค้า
          if (!req.session.cart) {
            req.session.cart = [];
          }
          req.session.cart.push({
            productId,
            productName,
            quantity,
            unitPrice,
            totalPrice
          });

          res.redirect('/cart');
        });
      });
    }
  });

  app.get('/cart', (req, res) => {
    if (!req.session.cart || req.session.cart.length === 0) {
      return res.send('ตะกร้าสินค้าว่าง');
    }
  
    let cartItems = req.session.cart;

    res.render('cart', { cartItems });
  });

  app.get('/checkout', (req, res) => {
    // ตรวจสอบว่ามีข้อมูลตะกร้าสินค้าใน session หรือไม่
    if (!req.session.cart || req.session.cart.length === 0) {
      return res.send('ไม่มีสินค้าที่จะชำระเงิน');
    }
  
    // ดึงข้อมูลตะกร้าสินค้าจาก session
    const cartItems = req.session.cart;
    console.log(req.session.cart);
    // ส่งข้อมูลไปยังหน้า checkout.ejs
    res.render('checkout', { cartItems });
  });

app.post('/checkout', (req, res) => {
    const customerId = req.body.customerId;

    // ตรวจสอบว่ามีคำสั่งซื้อที่ยังไม่ชำระเงินอยู่หรือไม่
    const getOrderQuery = `SELECT order_id FROM orders WHERE customer_id = ? AND total_amount IS NULL`;
    pool.query(getOrderQuery, [customerId], (err, orderResult) => {
        if (err) {
            console.error('Error checking orders:', err);
            return res.status(500).send('Error checking orders: ' + err.message);
        }

        let orderId;
        if (orderResult.length === 0) {
            return res.status(400).send('ไม่พบคำสั่งซื้อ');
        } else {
            orderId = orderResult[0].order_id;

            // คำนวณยอดรวมจากตะกร้า
            let totalAmount = req.session.cart.reduce((total, item) => {
                return total + (item.product_price * item.quantity);
            }, 0);

            // อัปเดตยอดรวมในคำสั่งซื้อ
            const updateOrderQuery = `UPDATE orders SET total_amount = ?, payment_method = ? WHERE order_id = ?`;
            pool.query(updateOrderQuery, [totalAmount, req.body.paymentMethod, orderId], (err) => {
                if (err) {
                    console.error('Error updating order:', err);
                    return res.status(500).send('Error updating order: ' + err.message);
                }

                // ล้างข้อมูลตะกร้า
                req.session.cart = [];

                res.send('ยืนยันการสั่งซื้อสำเร็จ');
            });
        }
    });
});

app.post('/place-order', (req, res) => {
    const customerId = 1; // สมมติว่าลูกค้าถูกล็อกอินแล้ว
    const { total_amount, discounted_total, payment_method } = req.body;

    console.log('Request Body:', req.body); // ตรวจสอบว่าได้ข้อมูลจากฟอร์มหรือไม่

    const sql = `
        INSERT INTO orders (customer_id, total_amount, payment_method)
        VALUES (?, ?, ?)
    `;

    // บันทึกคำสั่งลงฐานข้อมูล
    db.query(sql, [customerId, discounted_total, payment_method], (err, result) => {
        if (err) {
            console.error('Error in placing the order:', err); // ดูรายละเอียด error
            return res.status(500).send(`Error in placing the order: ${err.message}`);
        }
        console.log('Insert Result:', result); // ตรวจสอบผลลัพธ์
        res.send('Order placed successfully');
    });
});

app.get('/get-discount', async (req, res) => {
    const first_name = req.query.customer_name;
    console.log("Received customer_name:", first_name); // Log received name

    try {
        const [rows] = await db.query('SELECT membership_id FROM customers WHERE first_name LIKE ?', [`%${first_name}%`]);
        
        console.log("Query rows:", rows);

        const customer = rows.length > 0 ? rows[0] : null;
        console.log("Customer data:", customer);

        if (!customer) {
            console.log("No customer found with the given name.");
            return res.status(404).json({ message: "Customer not found" });
        }

        let discount = 0;
        if (customer.membership_id === 1) discount = 0.05;
        else if (customer.membership_id === 2) discount = 0.10;
        else if (customer.membership_id === 3) discount = 0.15;

        console.log("Discount:", discount);
        res.json({ discount });
    } catch (error) {
        console.error("Error in /get-discount route:", error);
        res.status(500).json({ error: "Failed to fetch discount" });
    }
    
});

app.get('/', (req, res) => {
    pool.getConnection((err, connection) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error connecting to the database');
        }
        console.log("Connected with ID:", connection.threadId);

        connection.query('SELECT * FROM products', (err, rows) => { 
            connection.release();
            if (!err) {
                const obj = { products: rows };
                res.render('index', obj);
            } else {
                console.error(err);
                return res.status(500).send('Error querying the database');
            }
        });
    });
});

app.listen(port, () => 
    console.log("listen on port", port) // แก้ไขข้อความ log
)

// ฟังก์ชันตรวจสอบสินค้าใกล้หมดและสินค้าใกล้หมดอายุ
function checkAndCreateAlerts() {
    const lowStockThreshold = 100; // จำนวนคงเหลือที่ต่ำกว่าจำนวนนี้จะทำการแจ้งเตือน
    const expirationThreshold = 90; // จำนวนวันก่อนหมดอายุที่จะทำการแจ้งเตือน

    // คำสั่ง SQL สำหรับค้นหาสินค้าที่มีจำนวนใกล้หมด
    const lowStockQuery = `SELECT product_id, stock_quantity FROM products WHERE stock_quantity < ?`;

    // คำสั่ง SQL สำหรับค้นหาสินค้าที่ใกล้หมดอายุ
    const expirationQuery = `SELECT product_id, expiry_date FROM products WHERE expiry_date <= NOW() + INTERVAL ? DAY`;

    // ตรวจสอบสินค้าใกล้หมด
    pool.query(lowStockQuery, [lowStockThreshold], (err, results) => {
        if (err) throw err;

        results.forEach(product => {
            // เพิ่มการแจ้งเตือนสินค้าใกล้หมด
            const insertAlertQuery = `INSERT INTO alerts (product_id, alert_type, alert_date) VALUES (?, 'สินค้าใกล้หมด', NOW())`;
            pool.query(insertAlertQuery, [product.product_id], (err) => {
                if (err) throw err;
                console.log(`แจ้งเตือนสินค้าใกล้หมดสำหรับ product_id: ${product.product_id}`);
            });
        });
    });

    // ตรวจสอบสินค้าใกล้หมดอายุ
    pool.query(expirationQuery, [expirationThreshold], (err, results) => {
        if (err) throw err;

        results.forEach(product => {
            // เพิ่มการแจ้งเตือนสินค้าใกล้หมดอายุ
            const insertAlertQuery = `INSERT INTO alerts (product_id, alert_type, alert_date) VALUES (?, 'สินค้าใกล้หมดอายุ', NOW())`;
            pool.query(insertAlertQuery, [product.product_id], (err) => {
                if (err) throw err;
                console.log(`แจ้งเตือนสินค้าใกล้หมดอายุสำหรับ product_id: ${product.product_id}`);
            });
        });
    });


}

// เรียกใช้ฟังก์ชันในการตรวจสอบการแจ้งเตือน
checkAndCreateAlerts();